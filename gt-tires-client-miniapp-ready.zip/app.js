const screens = document.querySelectorAll(".screen");
const navButtons = document.querySelectorAll("[data-nav]");
const bottomButtons = document.querySelectorAll(".bottom-nav button");
const toast = document.getElementById("toast");

function openScreen(name){
  screens.forEach(s => s.classList.remove("active"));
  const target = document.getElementById("screen-" + name);
  if(target) target.classList.add("active");

  bottomButtons.forEach(b => b.classList.remove("active"));
  const activeBottom = document.querySelector(`.bottom-nav button[data-nav="${name}"]`);
  if(activeBottom) activeBottom.classList.add("active");
  if(["cars","tires","price","promo"].includes(name)){
    document.querySelector('.bottom-nav button[data-nav="home"]').classList.add("active");
  }

  window.scrollTo({top:0, behavior:"smooth"});
}

navButtons.forEach(btn => {
  btn.addEventListener("click", () => openScreen(btn.dataset.nav));
});

document.getElementById("bookingForm").addEventListener("submit", e => {
  e.preventDefault();
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1800);
  setTimeout(() => openScreen("orders"), 650);
});

/* Простий перемикач зайнятості для тесту:
   натисни 5 разів на картку зайнятості, і статус стане червоний/зелений */
let taps = 0;
const availabilityCard = document.getElementById("availabilityCard");
availabilityCard.addEventListener("click", () => {
  taps++;
  if(taps % 5 !== 0) return;
  const isBusy = availabilityCard.classList.toggle("busy");
  document.getElementById("statusText").textContent = isBusy ? "СЕРВІС ЗАЙНЯТИЙ" : "ВІЛЬНИЙ СЕРВІС";
  document.getElementById("statusHint").textContent = isBusy ? "Краще записатися на інший час" : "Зараз можна заїжджати";
});
